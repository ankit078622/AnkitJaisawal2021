package com.spring;

public class Address {
	
	
	private String addressinfo;

	public String getAddressinfo() {
		return addressinfo;
	}

	public void setAddressinfo(String addressinfo) {
		this.addressinfo = addressinfo;
	}
	
	
	
	public void AddressInfo() {
		
		System.out.println("address of yours"+addressinfo);
		
	}

}
