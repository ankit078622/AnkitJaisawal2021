package com.spring;

public class SpellChecker {

	// this constructor
	public SpellChecker() {
		
		

		System.out.println("inside  SpellChecker constructor");
	}

	// this method for spell checker

	public void checkSpelling() {
		// developer has to write a logic for spellchecker

		System.out.println("inside  SpellChecker method");
	}

}
