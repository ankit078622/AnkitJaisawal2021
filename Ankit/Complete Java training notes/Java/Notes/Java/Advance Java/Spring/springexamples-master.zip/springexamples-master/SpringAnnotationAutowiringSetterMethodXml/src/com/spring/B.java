package com.spring;

public class B {
	
	B b;

	// Constructor
	public B() {
		System.out.println(" From B, is created");

	}

	// method created here and need to call from other class


	
	// B b =new B()
	
	public void print() {

		System.out.println(" from hello B"+b.hashCode());

	}

}
