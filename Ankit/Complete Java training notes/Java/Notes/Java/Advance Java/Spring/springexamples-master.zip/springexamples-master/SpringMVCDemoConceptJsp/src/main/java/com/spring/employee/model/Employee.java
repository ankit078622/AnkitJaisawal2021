package com.spring.employee.model;

public class Employee {
	
	private Integer id;
	private String empname;
	private String empage;
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getEmpage() {
		return empage;
	}
	public void setEmpage(String empage) {
		this.empage = empage;
	} 
	
	
	

}
