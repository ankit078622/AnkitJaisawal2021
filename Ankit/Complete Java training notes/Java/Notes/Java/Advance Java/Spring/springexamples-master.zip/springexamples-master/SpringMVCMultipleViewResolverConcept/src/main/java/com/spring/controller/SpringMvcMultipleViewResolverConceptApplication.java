package com.spring.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcMultipleViewResolverConceptApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcMultipleViewResolverConceptApplication.class, args);
	}

}
