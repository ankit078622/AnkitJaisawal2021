package com.spring.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcMultipleViewResolverConceptApplicationTests {

	@Test
	void contextLoads() {
	}

}
