package com.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {
	
	public static void main(String ar[]) {

		      ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		      JavaCollection jc=(JavaCollection)context.getBean("javaCollection");

		      jc.getAddressList();
		      jc.getAddressSet();
		      jc.getAddressMap();
		      jc.getAddressProp();

	}

}
