package com.spring;

public class SpellChecker {

	// constructor
	public SpellChecker() {

		System.out.println(" from  speill check constructor");
	}

	// method of spell checker class

	public void SpellCheckerMy() {

		System.out.println(" from  speill check SpellCheckerMy() method");

	}

}
