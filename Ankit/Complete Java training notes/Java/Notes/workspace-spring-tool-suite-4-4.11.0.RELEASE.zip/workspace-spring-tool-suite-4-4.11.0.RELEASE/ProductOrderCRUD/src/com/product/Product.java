package com.product;

public class Product {

}
