package com.Addition;

public class AdditionService {
	
	public int calculateAddition(int num1,int num2) {
		return num1+num2;
	}

}
