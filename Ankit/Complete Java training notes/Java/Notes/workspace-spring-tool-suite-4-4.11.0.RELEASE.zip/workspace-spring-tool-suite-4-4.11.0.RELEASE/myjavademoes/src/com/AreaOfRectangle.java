package com;

public class AreaOfRectangle {
	public static void main(String args[]) {
		float length=(float) 15.2;
		float width=(float) 12.5;
		float temp=(float) (length*width);
		System.out.println("Area Of Rectangle "+temp);
	}

}
