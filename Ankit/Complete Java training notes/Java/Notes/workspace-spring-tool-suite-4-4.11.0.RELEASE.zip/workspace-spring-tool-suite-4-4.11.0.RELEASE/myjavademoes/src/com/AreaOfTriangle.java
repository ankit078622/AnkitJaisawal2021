package com;

public class AreaOfTriangle {
	public static void main(String args[]) {
		float base=(float) 10.0;
		float height=(float) 5.6;
		float temp=(float)((1.0/2.0)*base*height);
		System.out.println("Area Of Triangle "+temp);
		
	}

}
