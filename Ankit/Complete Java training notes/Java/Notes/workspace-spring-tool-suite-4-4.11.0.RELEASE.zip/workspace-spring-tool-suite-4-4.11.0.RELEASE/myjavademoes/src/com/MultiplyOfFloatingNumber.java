package com;

public class MultiplyOfFloatingNumber {
	
	public static void main(String args[])	{
		float numberone=(float) 5.8;
		float numbertwo=(float) 7.5;
		float temp=(float) (numberone*numbertwo);
		System.out.println("Multiplication of two floating number is "+temp);
	}

}
