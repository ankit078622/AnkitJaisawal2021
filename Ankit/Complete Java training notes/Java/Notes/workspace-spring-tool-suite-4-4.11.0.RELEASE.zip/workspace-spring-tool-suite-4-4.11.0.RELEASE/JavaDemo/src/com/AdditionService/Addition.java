package com.AdditionService;

public class Addition {

	public int getAddition(int num1,int num2) {
		return num1+num2;
	}
}
