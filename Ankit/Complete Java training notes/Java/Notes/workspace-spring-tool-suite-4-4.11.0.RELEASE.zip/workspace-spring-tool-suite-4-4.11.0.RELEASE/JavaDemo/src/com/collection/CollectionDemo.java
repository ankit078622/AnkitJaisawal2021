package com.collection;

interface Rectangle{
	
}
interface Circle extends Rectangle{
	
}
class Area implements Circle{
	
}
public class CollectionDemo {

}
