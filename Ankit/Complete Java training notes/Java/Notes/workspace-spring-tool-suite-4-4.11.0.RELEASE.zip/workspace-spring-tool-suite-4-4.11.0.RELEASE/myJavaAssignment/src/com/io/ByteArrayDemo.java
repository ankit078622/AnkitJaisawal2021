package com.io;

import java.io.File;

public class ByteArrayDemo {
	
	public static void main(String args[]) {
		File file=new File("E:/io/abc.txt");
		
	}

}
