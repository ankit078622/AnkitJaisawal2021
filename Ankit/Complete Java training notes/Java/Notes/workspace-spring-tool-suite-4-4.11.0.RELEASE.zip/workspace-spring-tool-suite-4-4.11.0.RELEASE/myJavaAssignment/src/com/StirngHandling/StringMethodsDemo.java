package com.StirngHandling;

public class StringMethodsDemo {
	
	public static void main(String args[]) {
		
		//charAt(index) method working demo
		String s="Core Java";		
		System.out.println("The char is : "+s.charAt(3));
		
	    //length() method this is used to return the length of the string
		System.out.println("Length of the string is : "+s.length());
		
		//toLowerCase() method
		System.out.println("String in lower case : "+s.toLowerCase());
		
		//toUpperCase() method
		System.out.println("String in Upper case : "+s.toUpperCase());
						
	}

}
