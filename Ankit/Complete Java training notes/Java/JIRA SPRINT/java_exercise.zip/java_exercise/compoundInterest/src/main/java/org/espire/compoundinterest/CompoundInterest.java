package org.espire.compoundinterest;

public class CompoundInterest {
	
	public static Integer calculateCompoundInterest() {
		
		return 1;
	}
	public static void main(String[] args) {
		
	}
}
