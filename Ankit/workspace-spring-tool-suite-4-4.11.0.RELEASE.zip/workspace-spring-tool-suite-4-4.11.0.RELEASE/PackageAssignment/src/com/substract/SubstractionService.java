package com.substract;

public class SubstractionService {
	
	public int calculateSubstraction(int num1,int num2) {
		return num1-num2;
	}

}
