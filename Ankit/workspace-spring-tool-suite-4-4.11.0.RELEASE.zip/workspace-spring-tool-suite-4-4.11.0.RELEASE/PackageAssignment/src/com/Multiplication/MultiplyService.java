package com.Multiplication;

public class MultiplyService {
	
	public int calculateMultiplication(int num1,int num2) {
		return num1*num2;
	}

}
