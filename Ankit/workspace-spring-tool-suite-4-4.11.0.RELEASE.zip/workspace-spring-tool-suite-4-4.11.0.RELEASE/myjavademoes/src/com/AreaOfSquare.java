package com;

public class AreaOfSquare {
	public static void main(String args[]) {
		float numberone=(float)8.5;
		float numbertwo=(float)8.5;
		float temp=(float)(numberone*numbertwo);
		System.out.println("Area Of Square "+temp);
			
	}
	
}