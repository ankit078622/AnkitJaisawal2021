package com;

public class AdditionDemo {
	
	public static void main(String args[]) {
		int numberone=5;
		int numbertwo=7;
		int temp=numberone+numbertwo;
		System.out.println("Addition of two numbers "+temp);		
	}
}
