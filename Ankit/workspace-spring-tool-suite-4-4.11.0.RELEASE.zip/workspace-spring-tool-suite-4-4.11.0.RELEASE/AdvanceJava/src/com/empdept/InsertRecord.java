package com.empdept;

public class InsertRecord {

	public static void main(String args[]) {
		
	}
}
