package com.collection;
//1.Write a Java program to append the specified element to the end of a hash set.
public class AppendAtTheEndOfHashSet {

	public static void main(String args[]) {
		
	}
}
