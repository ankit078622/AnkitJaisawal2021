package com.SubstractionService;

public class Substract {
	public int getSubstract(int num1,int num2) {
		return num1-num2;
	}

}
