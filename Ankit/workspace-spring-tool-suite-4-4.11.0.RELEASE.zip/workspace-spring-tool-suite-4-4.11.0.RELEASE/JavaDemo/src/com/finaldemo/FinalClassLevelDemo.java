package com.finaldemo;
final class ABC{
	
}
/*public class FinalClassLevelDemo extends ABC{

	void demo() {
		System.out.println("My method");
	}
	public static void main(String args[]) {
		FinalClassLevelDemo obj=new FinalClassLevelDemo();
		obj.demo();
	}
}
*/