package com.Interface;

interface A{
	
}
class B implements A{
	
}
interface C extends A{
	
}

class D extends B implements C{
	
}

public class MultipleInheiDemo {

}
