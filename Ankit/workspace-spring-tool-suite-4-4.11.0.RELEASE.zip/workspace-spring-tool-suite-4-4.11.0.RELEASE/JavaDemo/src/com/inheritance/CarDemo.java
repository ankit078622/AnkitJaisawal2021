package com.inheritance;
//Multilevel inheritance
abstract class Car{
	Car(){
		
	}
	void showSpeed() {
		System.out.println("50");
	}
}


public class CarDemo {
 
	public static void main(String args[]) {
		
	}
}
