package org.espire.main;

import static org.junit.Assert.*;

import org.junit.Test;

public class VendingMachineTest {

	@Test
	public void testVendingMachine() {
		//VendingMachine.vendingMachine();
	}

}
