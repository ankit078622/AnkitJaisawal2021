package org.espire.main;

import org.espire.service.VendingMachineService;

public class VendingMachine {
	public static void main(String[] args) {
		VendingMachineService vendingMachineService = new VendingMachineService();
		vendingMachineService.vendingMachineService();
	}
}
