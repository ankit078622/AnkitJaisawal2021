/**
 * 
 */
package org.espire.linkedlist;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author ankit.jaisawal
 *
 */
public class FindLengthOfSinglyLinkedListTest {

	/**
	 * Test method for {@link org.espire.linkedlist.FindLengthOfSinglyLinkedList#singlyLinkedListLength()}.
	 */
	@Test
	public void testSinglyLinkedListLength() {
		FindLengthOfSinglyLinkedList.singlyLinkedListLength();
	}

}
