package com.espire.spring.serviceImpl;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.espire.spring.model.Employee;
import com.espire.spring.model.request.EmployeeCreateRequest;
import com.espire.spring.repository.EmployeeRepository;
import com.espire.spring.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	// Creating object
	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	BCryptPasswordEncoder passwordEncoder;
	
	public Employee readByUsername(String username) {
		return employeeRepository.findByUsername(username).orElseThrow(EntityNotFoundException::new);
	}

	@Override
	public void createEmployee(EmployeeCreateRequest empCreateRequest) {
		Employee employee = new Employee();
		Optional<Employee> byUsername = employeeRepository.findByUsername(empCreateRequest.getUsername());
		employee.setUsername(empCreateRequest.getUsername());
		employee.setPassword(passwordEncoder.encode(empCreateRequest.getPassword()));
		employeeRepository.save(employee);

	}

	/**
	 * Method for get all the employee list present in the database
	 */
	@Override
	public List<Employee> getAllEmployee() {
		List<Employee> employees = employeeRepository.findAll();
		return employees;
	}

	/**
	 * Method for add employee details
	 */
	@Override
	public Employee addEmployee(Employee employee) {
		Employee employee2 = employeeRepository.save(employee);
		return employee2;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		Employee employee2 = employeeRepository.save(employee);
		return employee2;
	}

	@Override
	public void deleteEmployee(Integer employeeId) {
		employeeRepository.deleteById(employeeId);
	}

	

}
