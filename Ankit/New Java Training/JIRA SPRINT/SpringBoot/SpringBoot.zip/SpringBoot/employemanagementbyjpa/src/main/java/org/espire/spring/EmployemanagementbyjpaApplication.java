package org.espire.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployemanagementbyjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployemanagementbyjpaApplication.class, args);
	}

}
