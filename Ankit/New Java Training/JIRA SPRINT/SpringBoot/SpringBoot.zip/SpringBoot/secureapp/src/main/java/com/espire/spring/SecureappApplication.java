package com.espire.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecureappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecureappApplication.class, args);
	}

}
