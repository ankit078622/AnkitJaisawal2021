package com.espire.spring.service;

import java.util.List;

import com.espire.spring.model.Employee;
import com.espire.spring.model.request.EmployeeCreateRequest;

public interface EmployeeService {

	void createEmployee(EmployeeCreateRequest empCreateRequest);
	
	List<Employee> getAllEmployee();

	Employee addEmployee(Employee employee);

	Employee updateEmployee(Employee employee);

	void deleteEmployee(Integer employeeId);
}
