package com.espire.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeemanagemnetjwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeemanagemnetjwtApplication.class, args);
	}

}
